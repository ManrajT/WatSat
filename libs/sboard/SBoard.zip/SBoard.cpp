/*
 May 17, 2014
 
 A module to model the watsat adcs board that consists of 
    - 2 photodiodes
    - a temperature sensor
    - a double axis magnetometer
*/

#include <Arduino.h>
#include "SBoard.h"

SBoard::SBoard()
{
    control_lines[] = {}; 
}
