#ifndef SBoard_h
#define SBoard_h

#include <Arduino.h>

class SBoard
{
    public:
        SBoard();

};

#endif
